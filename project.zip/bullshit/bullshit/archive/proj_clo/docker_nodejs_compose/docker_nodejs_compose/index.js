const express = require("express");
const morgan = require('morgan')
const app = express()
const db = require('./db')
const PORT = process.env.PORT || 3000


app.use(morgan('dev'))
app.use(express.json())
app.use(express.urlencoded({ extended: true }))

app.get('/', (req, res) => res.send('Hello World!'))

app.get('/users', async (req, res) => {
  const users = await db.select().from('users')

  res.json(users)
})
app.get('/products', async (req, res) => {
  const products = await db.select().from('products')

  res.json(products)
})

app.post('/users', async (req, res) => {
  const { username,Email, password } = req.body; // Extracting name, price, and quantity from the request body
  const user = await db('users').insert({ username, Email, password }).returning('*'); // Inserting all properties into the database
  res.json(user);
})
app.post('/products', async (req, res) => {
  const { name, price, quantity } = req.body; // Extracting name, price, and quantity from the request body
  const product = await db('products').insert({ name, price, quantity }).returning('*'); // Inserting all properties into the database
  res.json(product);
});


app.listen(PORT, () => console.log(`Server up at PORT:${PORT}`))
