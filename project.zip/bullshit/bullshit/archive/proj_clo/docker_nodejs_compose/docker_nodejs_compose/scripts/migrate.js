const db = require('../db');

(async () => {
  try {
    await db.schema.dropTableIfExists('users');
    await db.schema.withSchema('public').createTable('users', (table) => {
      table.increments();
      table.string('username');
      table.string('Email');
      table.string('password');
    });
    console.log('Created users table!');

    // Add code for creating the products table here
    await db.schema.dropTableIfExists('products');
    await db.schema.withSchema('public').createTable('products', (table) => {
      table.increments();
      table.string('name');
      table.decimal('price', 10, 2);
      table.integer('quantity').unsigned().defaultTo(0);
      table.timestamps(true, true);
    });
    console.log('Created products table!');

    process.exit(0);
  } catch (err) {
    console.log(err);
    process.exit(1);
  }
})();

