const db = require('../db');

(async () => {
  try {
    // Insert dummy data into the users table
    await db('users').insert({ username: 'Menna', Email: "menna@yahoo.com", password: "123" });
    await db('users').insert({ username: 'Ansam', Email: "ansam@yahoo.com", password: "AAA" });
    await db('users').insert({ username: 'alaa', Email: "alaa@yahoo.com", password: "BBB" });
    console.log('Added dummy users!');

    // Insert dummy data into the products table
    await db('products').insert({ name: 'Product 1', price: 10.99, quantity: 100 });
    await db('products').insert({ name: 'Product 2', price: 19.99, quantity: 50 });
    await db('products').insert({ name: 'Product 3', price: 5.49, quantity: 200 });
    console.log('Added dummy products!');

    process.exit(0);
  } catch (err) {
    console.log(err);
    process.exit(1);
  }
})();