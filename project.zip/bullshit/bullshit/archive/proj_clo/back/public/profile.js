document.getElementById('login-form').addEventListener('submit', function(event) {
  event.preventDefault();
  var username = document.getElementById('login-username').value;
  var password = document.getElementById('login-password').value;

  fetch('http://localhost:3000/login', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ username, password })
  })
 .then(response => {
    if (response.ok) {
      return response.text(); // Expect a text response
    } else {
      throw new Error('Incorrect username or password.');
    }
  })
 .then(data => {
    if (data === 'Login successful') {
      // Redirect to index.html upon successful login
      window.location.href = 'index.html';
    } else {
      alert('Login failed');
    }
  })
 .catch(error => {
    alert(error.message);
  });
});


// Other functions (updateProfileUI, closeModal, etc.) remain unchanged

 
 
 function updateProfileUI(user) {
   if (user && user.isLoggedIn) {
     // User is logged in, adjust UI as needed
     document.getElementById('profile-icon').textContent = 'Welcome, ' + user.username;
   } else {
     // User is not logged in, show login/signup options
     document.getElementById('profile-icon').textContent = 'Login/Signup';
   }
 }
 
 document.addEventListener('DOMContentLoaded', function() {
   var user = JSON.parse(localStorage.getItem('user'));
   updateProfileUI(user);
 });
 
 document.getElementById('signup-form').addEventListener('submit', function(event) {
   event.preventDefault();
   var username = document.getElementById('signup-username').value;
   var email = document.getElementById('signup-email').value;
   var password = document.getElementById('signup-password').value;
 
   // Check if the username is already taken
   var existingUser = JSON.parse(localStorage.getItem('user'));
   if (existingUser && existingUser.username === username) {
     alert('Username is already taken.');
     return;
   }
 
   // Simulate account creation
   var user = {
     username: username,
     email: email,
     password: password, // Note: Storing passwords in plain text is not secure
     isLoggedIn: true
   };
   localStorage.setItem('user', JSON.stringify(user));
   alert('Account created successfully!');
   closeModal('signup-modal'); // Close the signup modal
 });
 
 function closeModal(modalId) {
   document.getElementById(modalId).style.display = 'none';
 }
 