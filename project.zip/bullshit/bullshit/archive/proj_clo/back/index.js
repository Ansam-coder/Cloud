const express = require('express');
const { Pool } = require('pg');
const path = require('path');

const app = express();
const port = 3000;

// PostgreSQL database configuration
const pool = new Pool({
  user: 'postgres',
  host: 'db',
  database: 'testUser',
  password: 'postgres',
  port: 5432,
});

app.use(express.json());

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Route for user login
app.post('/login', async (req, res) => {
  const { username, password } = req.body;

  try {
    // Check if username and password match in the database
    const query = 'SELECT * FROM users WHERE username = $1 AND password = $2';
    const values = [username, password];

    const { rows } = await pool.query(query, values);

    if (rows.length === 0) {
      res.status(401).json({ message: 'Invalid username or password' });
    } else {
      // Redirect to index.html after successful login
      res.redirect('/index.html');
    }
  } catch (error) {
    console.error('Error logging in:', error);
    res.status(500).json({ message: 'Error logging in. Please try again later.' });
  }
});

// Route for user signup
app.post('/signup', async (req, res) => {
  const { username, email, password } = req.body;

  try {
    // Check if username or email already exists in the database
    const query = 'SELECT * FROM users WHERE username = $1 OR email = $2';
    const values = [username, email];

    const { rows } = await pool.query(query, values);

    if (rows.length > 0) {
      res.status(409).json({ message: 'Username or email already exists' });
    } else {
      // Insert the new user into the database
      const insertQuery = 'INSERT INTO users (username, email, password) VALUES ($1, $2, $3)';
      const insertValues = [username, email, password];

      await pool.query(insertQuery, insertValues);

      res.status(201).json({ message: 'Account created successfully' });
    }
  } catch (error) {
    console.error('Error creating account:', error);
    res.status(500).json({ message: 'Error creating account. Please try again later.' });
  }
});

app.get('*', function (req, res) {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});