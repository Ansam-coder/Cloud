document.addEventListener('DOMContentLoaded', function() {
  var signupModal = document.getElementById('signup-modal');
  var closeModal = document.getElementsByClassName('close-modal')[0];

  // Show the signup modal
  // Show the signup modal
document.getElementById('signup-link').addEventListener('click', function(event) {
  event.preventDefault();
  signupModal.style.display = 'block';
});
  // Close the signup modal
  closeModal.addEventListener('click', function() {
    signupModal.style.display = 'none';
  });

  // Send a signup request to the server
  document.getElementById('signup-form').addEventListener('submit', function(event) {
    event.preventDefault();
    var username = document.getElementById('signup-username').value;
    var email = document.getElementById('signup-email').value;
    var password = document.getElementById('signup-password').value;

    fetch('http://localhost:3000/signup', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ username, email, password })
    })
      .then(response => {
        if (response.ok) {
          return response.json(); // Expect a JSON response
        } else {
          throw new Error('Error creating account');
        }
      })
      .then(data => {
        alert(data.message);
        if (data.message === 'Account created successfully') {
          // Redirect to index.html upon successful signup
          window.location.href = 'index.html';
        }
      })
      .catch(error => {
        alert(error.message);
      });
  });
});