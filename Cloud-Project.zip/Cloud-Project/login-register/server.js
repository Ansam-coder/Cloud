const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const route = require('./route');

const app = express();
const port = 3000;

// MySQL Connection
const connection = mysql.createConnection({
  host: 'mysql-container',
  user: 'root',
  password: '20201700558',
  database: 'projectdb'
});

connection.connect((err) => {
  if (err) {
    console.error('Error connecting to database: ' + err.stack);
    return;
  }
  console.log('Connected to database');
});

// Middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Serving static files (assuming they're in a directory named 'Frontend/register')
app.use(express.static('public'));

// Route to handle user registration
app.post('/register', (req, res) => {
  const { username, userEmail, userPassword, userAddress, userPhone } = req.body;
  const insertQuery = 'INSERT INTO user_ (username, userEmail, userPassword, userAddress, userPhone) VALUES (?, ?, ?, ?, ?)';
  connection.query(insertQuery, [username, userEmail, userPassword, userAddress, userPhone], (err, result) => {
    if (err) {
      console.error('Error registering user: ' + err.stack);
      res.status(500).json({ error: 'Error registering user' });
      return;
    }
    console.log('User registered successfully');
    //res.status(200).json({ message: 'User registered successfully' });
    res.redirect('/login/index.html');
  });
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const query = 'SELECT * FROM user_ WHERE username = ? AND userPassword = ?';
  
  connection.query(query, [username, password], (err, results) => {
    if (err) {
      console.error('Error authenticating user:', err);
      res.status(500).json({ error: 'Error authenticating user' });
      return;
    }

    // Check if the query returned any results
    if (results.length === 0) {
      // If no results, the username or password is incorrect
      res.status(401).json({ error: 'Invalid username or password' });
    } else {
      // If results were found, user is authenticated
      // Set session or generate token and return success response
      res.status(200).json({ message: 'User authenticated successfully' });
    }
  });
});

// Error handling middleware for 404 errors (resource not found)
app.use((req, res, next) => {
  res.status(404).send("Sorry, the page you're looking for doesn't exist.");
});

// Error handling middleware for other errors
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send('Something went wrong on the server!');
});

// Use the routes
app.use('/', route);

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
