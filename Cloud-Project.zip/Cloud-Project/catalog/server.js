const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const path = require('path'); // Import the path module
const app = express();
const port = 3000;
// Create a MySQL connection
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '20201700558',
    database: 'projectdb'
});

// Connect to the MySQL database
connection.connect((err) => {
    if (err) {
        console.error('Error connecting to database: ' + err.stack);
        return;
    }
    console.log('Connected to database');
});
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
// Serving static files (assuming they're in a directory named 'Frontend/register')
app.use(express.static('public'));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});
// Define route to get all products
app.get('/products', (req, res) => {
    connection.query('SELECT * FROM product', (error, results) => {
        if (error) {
            console.error('Error executing query: ' + error.stack);
            return res.status(500).json({ error: 'Internal Server Error' });
        }
        res.json(results);
    });
});
// Define route to add a product to the cart
app.post('/cart', (req, res) => {
    const { userId, productId } = req.body;
    // Perform validation if needed

    // Add the product to the cart
    connection.query('INSERT INTO cart (userId, productId) VALUES (?, ?)', [1, 1], (error, results) => {
        if (error) {
            console.error('Error executing query: ' + error.stack);
            return res.status(500).json({ error: 'Internal Server Error' });
        }
        res.json({ message: 'Product added to cart successfully' });
    });
});
// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
